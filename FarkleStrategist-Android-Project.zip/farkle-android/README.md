# Farkle Strategist — Android project

This is an Android Studio project that packages the Farkle Strategist app in a native Android WebView shell. The app itself is offline-capable and stores turn state/history locally on the device.

## Build an APK in Android Studio

1. Install Android Studio (current stable) and the Android 35 SDK platform/build tools.
2. Open this folder (`FarkleStrategist`) in Android Studio.
3. Let Gradle sync finish.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will create `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy that APK to your Android phone and open it to install. If Android asks, allow installation from that source.

## Build with Gradle from a terminal

Requires JDK 17, Gradle 8.9, and Android SDK Platform 35 / Build Tools 35.0.0:

```bash
gradle assembleDebug
```

The debug APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## Build automatically with GitHub Actions

Push this project to a GitHub repository on the `main` branch, or use **Actions → Build Android APK → Run workflow**. The workflow builds the debug APK and attaches it as an artifact named `Farkle-Strategist-debug-apk`.

## Project layout

- `app/src/main/assets/index.html` — app UI, scoring, dice selection, probability calculations, and local history.
- `app/src/main/java/.../MainActivity.java` — Android WebView host.
- `app/src/main/AndroidManifest.xml` — app declaration.
- `.github/workflows/android.yml` — cloud APK build workflow.

## Current scoring behavior

- Single 1 = 100; single 5 = 50.
- Triple 1 = 1,000; other triples = face × 100.
- Four/five/six of a kind multiply the triple score by 2/4/8.
- Small straight 1–5 or 2–6 = 750, requiring all five dice in the same roll.
- Large straight 1–6 = 1,500, requiring all six dice in the same roll.
- A five-die straight can be selected from a six-die roll; an extra 1 or 5 can score separately.
- Previously kept dice remain locked and are not combined with a later roll to make a straight.

The strategy display estimates the next-roll farkle chance by enumerating dice outcomes. It is a heuristic decision aid; the player always chooses whether to keep, bank, or continue.
